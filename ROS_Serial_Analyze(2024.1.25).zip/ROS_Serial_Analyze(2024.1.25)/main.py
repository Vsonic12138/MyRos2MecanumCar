import serial
import time
from serial.tools import list_ports
import os

def find_serial_ports():
    # 列出所有可用的串口
    ports = list(list_ports.comports())
    return [port.device for port in ports]

def select_serial_port(available_ports):
    print("可用串口:")
    for i, port in enumerate(available_ports):
        print(f"{i + 1}. {port}")

    while True:
        try:
            selection = int(input("请选择要使用的串口编号: "))
            if 1 <= selection <= len(available_ports):
                return available_ports[selection - 1]
            else:
                print("无效的选择，请重新输入.")
        except ValueError:
            print("请输入一个有效的数字.")

# 解析车轮速度数据
def parse_wheel_speed_data(data):
    wheel_speed = {}
    print("传入的data:", ' '.join(format(byte, '02X') for byte in data))

    # 解析左前轮车速
    left_front_dir = data[0]
    left_front_speed = int.from_bytes(data[1:3], byteorder='little', signed=False)
    if left_front_dir == 0x00:  #0x00为反转
        left_front_speed = -left_front_speed
    elif left_front_dir == 0xFF: #0xFF为正转
        left_front_speed = left_front_speed
    wheel_speed['Left_Front_Speed'] = left_front_speed

    # 解析右前轮车速
    right_front_dir = data[3]
    right_front_speed = int.from_bytes(data[4:6], byteorder='little', signed=False)
    if right_front_dir == 0x00:
        right_front_speed = -right_front_speed
    elif right_front_dir == 0xFF:
        right_front_speed = right_front_speed
    wheel_speed['Right_Front_Speed'] = right_front_speed

    # 解析右后轮车速
    right_rear_dir = data[6]
    right_rear_speed = int.from_bytes(data[7:9], byteorder='little', signed=False)
    if right_rear_dir == 0x00:
        right_rear_speed = -right_rear_speed
    elif right_rear_dir == 0xFF:
        right_rear_speed = +right_rear_speed
    wheel_speed['Right_Rear_Speed'] = right_rear_speed

    # 解析左后轮车速
    left_rear_dir = data[9]
    left_rear_speed = int.from_bytes(data[10:12], byteorder='little', signed=False)
    if left_rear_dir == 0x00:
        left_rear_speed = -left_rear_speed
    elif left_rear_dir == 0xFF:
        left_rear_speed = +left_rear_speed
    wheel_speed['Left_Rear_Speed'] = left_rear_speed

    return wheel_speed

#加速度
def parse_acceleration_data(data):
    acceleration = {}
    print("传入的data:", ' '.join(format(byte, '02X') for byte in data))
    acceleration['AccX'] = (int.from_bytes(data[0:2], byteorder='little', signed=True))/32768*16*9.8
    acceleration['ACCY'] = (int.from_bytes(data[2:4], byteorder='little', signed=True))/32768*16*9.8
    acceleration['ACCZ'] = (int.from_bytes(data[4:6], byteorder='little', signed=True))/32768*16*9.8
    return acceleration

#角速度
def parse_angular_velocity_data(data):
    angular_velocity = {}
    print("传入的data:", ' '.join(format(byte, '02X') for byte in data))
    angular_velocity['gyroX'] = (int.from_bytes(data[0:2], byteorder='little', signed=True))/32768*2000
    angular_velocity['gyroY'] = (int.from_bytes(data[2:4], byteorder='little', signed=True))/32768*2000
    angular_velocity['gyroZ'] = (int.from_bytes(data[4:6], byteorder='little', signed=True))/32768*2000
    return angular_velocity

#欧拉角
def parse_euler_angle_data(data):
    euler_angle = {}
    print("传入的data:", ' '.join(format(byte, '02X') for byte in data))
    euler_angle['Roll'] = (int.from_bytes(data[0:2], byteorder='little', signed=True))/32768*180
    euler_angle['Pitch'] = (int.from_bytes(data[2:4], byteorder='little', signed=True))/32768*180
    euler_angle['Yaw'] = (int.from_bytes(data[4:6], byteorder='little', signed=True))/32768*180
    return euler_angle



#电池电量
def parse_battery_data(data, integer_part=None):
    print("传入的data:", ' '.join(format(byte, '02X') for byte in data))

    integer_part = int.from_bytes(data[0:1], byteorder='little')

    decimal_part = int.from_bytes(data[1:2], byteorder='little')

    battery_voltage = integer_part * 100 + decimal_part
    return {'Battery Voltage': battery_voltage}




#用于计算校验位，获取全部的数据位，然后与上0XFF
def calculate_checksum(data):
    calcu_num = sum(data) & 0xFF
    print('校验结果如下：%#x' % calcu_num)
    return (calcu_num)

#用于判断帧头、帧尾、标志位和数据长度
def parse_serial_data(data):
    # 根据你的数据格式进行解析
    # 检查帧头和帧尾
    if data[0] != 0x55 or data[-1] != 0xBB:
        print("无效的数据帧")
        return None

    # 检查标识位和数据长度
    identifier = data[1]
    data_length = data[2]
    if data_length != 0x06:
        print("无效的数据长度")
        return None

    # 提取数据位
    data_payload = data[3:-2]
    #print(data_payload)

    # 计算校验位
    received_checksum = data[-2]
    calculated_checksum = calculate_checksum(data_payload)

    # 验证校验位
    if calculated_checksum != received_checksum:
        print("校验失败")
        return None

#验证完成之后清空传入的参数
    parsed_data = None

#利用标识位判断具体的数据，然后传入进行解析
    if identifier == 0x02:  # 车轮速度数据
        parsed_data = parse_wheel_speed_data(data_payload)
    elif identifier == 0x03:  # 加速度数据
       parsed_data = parse_acceleration_data(data_payload)
    elif identifier == 0x04:  # 角速度数据
        parsed_data = parse_angular_velocity_data(data_payload)
    elif identifier == 0x05:  # 欧拉角数据
        parsed_data = parse_euler_angle_data(data_payload)
    elif identifier == 0x06:  # 电池数据
        parsed_data = parse_battery_data(data_payload)


    return parsed_data

def read_frame_header(ser):
    timeout = 1  # 设置超时时间为1秒
    start_time = time.time()

    # 逐字节读取帧头
    while True:
        byte = ser.read(1)  # 读取一个字节
        if byte == b'\x55':  # 如果读取到了0x55
            next_byte = ser.read(1)  # 再读取下一个字节
            if next_byte:  # 如果下一个字节不为空
                return byte + next_byte  # 返回帧头
            else:  # 如果下一个字节为空（超时）
                return None
        elif time.time() - start_time > timeout:  # 超过了超时时间
            return None

def read_data_frame(ser):
    timeout = 1  # 设置超时时间为1秒
    start_time = time.time()

    frame_header_found = False  # 标志位，指示是否找到了帧头
    frame = b''  # 用于存储完整的数据帧

    # 读取数据帧
    while True:
        byte = ser.read(1)

        if byte == b'\x55' and not frame_header_found:  # 如果找到帧头
            frame_header_found = True
            frame = byte  # 存储帧头
        elif byte == b'\xBB' and frame_header_found:  # 如果找到帧尾
            frame += byte  # 存储帧尾
            break  # 结束读取
        elif not frame_header_found:  # 如果还没找到帧头
            continue
        else:  # 其他情况
            frame += byte  # 存储数据

        if time.time() - start_time > timeout:  # 超时
            return None

    print("完整数据帧:", ' '.join(format(byte, '02X') for byte in frame))
    return frame






def main():
    # 查找可用串口
    available_ports = find_serial_ports()

    if not available_ports:
        print("未找到可用串口")
        return

    # 手动选择串口
    selected_port = select_serial_port(available_ports)
    print(f"选择串口: {selected_port}")

    # 打开串口
    ser = serial.Serial(selected_port, baudrate=115200, timeout=1)

    # 不断的读取串口数据，做解析并且输出
    try:
        while True:
            # 读取数据帧
            data = read_data_frame(ser)
            if not data:
                print("无法读取数据帧，可能是超时")
                continue

            # 解析数据
            parsed_data = parse_serial_data(data)
            if parsed_data:
                print("解析结果:", parsed_data)

    except KeyboardInterrupt:
        print("程序已终止")

    finally:
        ser.close()

if __name__ == "__main__":
    main()
