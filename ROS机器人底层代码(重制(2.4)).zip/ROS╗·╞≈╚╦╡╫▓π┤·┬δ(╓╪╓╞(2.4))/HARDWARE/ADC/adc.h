#ifndef __ADC_H
#define __ADC_H	
#include "headfile.h"
 

void Adc_Init(void);
float Get_adc(u8 ch);
float Get_adc_Average(u8 ch,u8 times);
 
#endif 
