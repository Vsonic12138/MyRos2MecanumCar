#ifndef _PWM_H
#define _PWM_H


#include "headfile.h"

void TIM1_PWM_Init(u16 arr,u16 psc);
void TIM8_PWM_Init(u16 arr,u16 psc); 



#endif


