#ifndef _PID_CONTROL_H
#define _PID_CONTROL_H

#include "headfile.h"

/*�����Ŀ���ٶ�*/
extern int TargetSpeed_A,TargetSpeed_B,TargetSpeed_C,TargetSpeed_D;
/*��������ٶ�*/
extern int Final_X,Final_Y,Final_Z;
/*Ŀ��λ��*/
extern int Target_Position;
/*Ŀ��Ƕ�*/
extern int Target_Angle;
    
/*��������ֵ*/
extern int Encoder_A,Encoder_B,Encoder_C,Encoder_D;
/*��̬����������*/
extern float ROLL, PITCH, YAW;
extern float accX, accY, accZ;
extern float gyroX, gyroY, gyroZ;
/*���ֵõ���λ�ñ���*/
extern int Position_A,Position_B,Position_C,Position_D;
/*λ�û����*/
extern int moto_Position_A,moto_Position_B,moto_Position_C,moto_Position_D;
/*λ�û�����޷���ı�����Ҳ���ٶȻ�������*/
extern int limit_Motor_A,limit_Motor_B,limit_Motor_C,limit_Motor_D;
/*��������ٶ�*/
extern int Motor_A,Motor_B,Motor_C,Motor_D;  
/*ʱ����Ʊ�־λ*/
extern int count_10ms;
extern int count_20ms;
extern int count_40ms;
extern int count_100ms;


extern float a ;

void ControlLoop(void);

int Position_PID_A (int Encoder,int Target);
int Position_PID_B (int Encoder,int Target);
int Position_PID_C (int Encoder,int Target);
int Position_PID_D (int Encoder,int Target);

int Position_FeedbackControl_A(float Circle, int CurrentPosition);
int Position_FeedbackControl_B(float Circle, int CurrentPosition);
int Position_FeedbackControl_C(float Circle, int CurrentPosition);
int Position_FeedbackControl_D(float Circle, int CurrentPosition);

int Velocity_FeedbackControl_A(int TargetVelocity, int CurrentVelocity);
int Velocity_FeedbackControl_B(int TargetVelocity, int CurrentVelocity);
int Velocity_FeedbackControl_C(int TargetVelocity, int CurrentVelocity);
int Velocity_FeedbackControl_D(int TargetVelocity, int CurrentVelocity);

int Incremental_PI_A (int Target,int Encoder);
int Incremental_PI_B (int Target,int Encoder);
int Incremental_PI_C (int Target,int Encoder);
int Incremental_PI_D (int Target,int Encoder);

int Angle_Loop(int Re_Angle, int Ta_Angle);

int Limiting_amplitude(int value,int Amplitude);
void Set_Pwm(int motor_a,int motor_b,int motor_c,int motor_d);
int myabs(int a);
float mapToZeroThreeSixty(float angle);




#endif


