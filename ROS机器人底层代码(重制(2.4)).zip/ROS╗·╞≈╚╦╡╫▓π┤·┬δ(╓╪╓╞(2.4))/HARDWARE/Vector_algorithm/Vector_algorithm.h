#ifndef _VECTOR_ALGORITHM
#define _VECTOR_ALGORITHM

#include "headfile.h"

void mlyd(int x,int y,int f,int maxsdu);   


#endif



