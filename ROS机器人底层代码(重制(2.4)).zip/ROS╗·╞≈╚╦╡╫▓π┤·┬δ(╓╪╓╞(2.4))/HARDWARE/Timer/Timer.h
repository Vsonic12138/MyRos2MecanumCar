#ifndef _TIMER_H
#define _TIMER_H


#include "headfile.h"

void TIM6_Timer_Init(u16 arr,u16 psc);
void TIM7_Timer_Init(u16 arr,u16 psc);



#endif

