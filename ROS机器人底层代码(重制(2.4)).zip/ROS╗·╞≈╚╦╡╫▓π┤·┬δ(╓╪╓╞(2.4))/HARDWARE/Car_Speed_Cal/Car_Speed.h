#ifndef __Car_Speed_H
#define __Car_Speed_H

#include "headfile.h"

#define ENCODER_ID_A  3
#define ENCODER_ID_B  2
#define ENCODER_ID_C  5
#define ENCODER_ID_D  4

// ����ǰ�����ٶ�
extern int leftFrontSpeedNow;
extern int rightFrontSpeedNow;
extern int leftBackSpeedNow;
extern int rightBackSpeedNow;

// ����ǰ������
extern double lFSpd_mm_s;
extern double rFSpd_mm_s;
extern double lBSpd_mm_s;
extern double rBSpd_mm_s;

void Get_Motor_Speed(int *leftFrontSpeed, int *rightFrontSpeed, int *leftBackSpeed, int *rightBackSpeed);
void Encoder_Update_Count(u8 Encoder_id);
int Encoder_Get_Count_Now(u8 Encoder_id);
void Motion_Send_Data(void);

#endif

