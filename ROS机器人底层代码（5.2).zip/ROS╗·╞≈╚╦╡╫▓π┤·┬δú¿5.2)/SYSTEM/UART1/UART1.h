/***********************************************************************
Copyright (c) 2022, www.guyuehome.com

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

? ? http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/
#ifndef __UART1_H
#define __UART1_H

#include "headfile.h"

/*DMA���òο�����ƪ����
https://blog.csdn.net/hekuan5826/article/details/122648197
https://www.cnblogs.com/penuel/p/11264220.html
https://www.cnblogs.com/viggogao/p/11175101.html#:~:text=30%20DMA_InitStructure.DMA_PeripheralBaseAddr%20%3D%20USART1_DR_Base%3B%20%2F%2F%20%E5%A4%96%E8%AE%BE%E5%9C%B0%E5%9D%80%EF%BC%8C%E4%B8%B2%E5%8F%A31%EF%BC%8C%20%E5%8D%B3%E5%8F%91%E4%BB%B6%E7%9A%84%E5%BF%AB%E9%80%92%2031,37%20USART_DMACmd%28USART1%2C%20USART_DMAReq_Tx%7CUSART_DMAReq_Rx%2C%20ENABLE%29%3B%20%2F%2F%20%E4%BD%BF%E8%83%BDDMA%E4%B8%B2%E5%8F%A3%E5%8F%91%E9%80%81%E5%92%8C%E6%8E%A5%E5%8F%97%E8%AF%B7%E6%B1%82%2038%20%7D
https://blog.csdn.net/as480133937/article/details/104927922
https://zhuanlan.zhihu.com/p/652083815

����Ҫ�Ļ�����ƪ
https://blog.csdn.net/weixin_44524484/article/details/106029682
https://blog.csdn.net/weixin_44524484/article/details/105671273
*/


#define    USART1_MAX_TX_LEN		100			     	//����ͻ����ֽ���
#define    USART1_MAX_RX_LEN		10			     	//�����ջ����ֽ���
extern u8  USART1_TX_BUF[USART1_MAX_TX_LEN]; 	//���ͻ�����
extern u8  u1rxbuf[USART1_MAX_RX_LEN];				//�������ݻ�����1
extern u8	 u2rxbuf[USART1_MAX_RX_LEN];				//�������ݻ�����2
extern u8  witchbuf;                  				//��ǵ�ǰʹ�õ����ĸ�������,0,ʹ��u1rxbuf��1,ʹ��u2rxbuf��
extern u8 USART1_TX_FLAG;
extern u8 USART1_RX_FLAG;

void UART1_DMA_Init(unsigned long baudrate);
void DMA1_USART1_Init(void);
void DMA_USART1_Tx_Data(u8 *buffer, u32 size);
void USART1_printf(char *format, ...);

#endif
