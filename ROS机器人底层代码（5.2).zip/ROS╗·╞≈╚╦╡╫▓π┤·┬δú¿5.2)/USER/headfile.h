#ifndef __HEADFILE_H
#define __HEADFILE_H	 


#define USARTX USART2

//STM32F10Xϵ�а�������ͷ�ļ�
#include "stm32f10x.h"
//λ������
#include "sys.h"



#include "DIO.h"
#include "delay.h"
#include "key.h"
 
 
#include "UART1.h"	
#include "UART2.h"
#include "UART3.h"
#include "adc.h" 
#include "PWM.h"
#include "Encoder.h"

#include "pstwo.h"
#include "Timer.h"
#include "PID_Control.h"
#include "Driver.h"
#include "Car_Speed.h"

#include "JY62.h"
#include "protocol.h"
#include "Vector_algorithm.h"

//C�����Դ���
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include "misc.h"
#include "stdlib.h"
#include "math.h"
#include <stdint.h>




#endif

