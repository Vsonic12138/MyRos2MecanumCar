#ifndef _VECTOR_ALGORITHM
#define _VECTOR_ALGORITHM

#include "headfile.h"

void mlyd(int x,int y,int f,int maxsdu);   
void Kinematic_Analysis(float Vx,float Vy,float Vz);
void Kinematic_Positive_Analysis(float SpeedA,float SpeedB,float SpeedC,float SpeedD);


extern float dx;
extern float dy;

extern int8_t Act_velocity_X;
extern int8_t Act_velocity_Y;
extern int8_t Act_velocity_Z;

//ʵ�ʾ���
extern float Act_Distance_X;
extern float Act_Distance_Y;


#endif



