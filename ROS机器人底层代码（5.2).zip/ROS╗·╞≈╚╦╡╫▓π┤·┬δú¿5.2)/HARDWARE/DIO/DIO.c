#include "DIO.h"

/*************************************************************************************************
*	�� �� ��:	LED_and_BUZZER_IO_Init
*
*	��������:	IO�ڳ�ʼ��
*	 
*************************************************************************************************/

void LED_and_BUZZER_IO_Init(void)
{		
	GPIO_InitTypeDef GPIO_InitStructure; //����ṹ��
	RCC_APB2PeriphClockCmd ( RCC_APB2Periph_GPIOC , ENABLE); 	//��ʼ��GPIOʱ��	
				
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
	
	//��ʼ�� LED1 ����
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_1;	 
	GPIO_Init(GPIOC, &GPIO_InitStructure);	

	GPIO_ResetBits(GPIOC,GPIO_Pin_13);  //IO������͵�ƽ
	GPIO_ResetBits(GPIOC,GPIO_Pin_1);  //IO������͵�ƽ,������
}

void LED_ON()
{
	GPIO_ResetBits(GPIOC,GPIO_Pin_13);			// ����͵�ƽ������LED1	
}

void LED_OFF()
{
	GPIO_SetBits(GPIOC,GPIO_Pin_13);			// ����ߵ�ƽ���ر�LED1	
}



int melody[] = {50, 50, 50, 50, 200, 200, 200, 400, 400, 500, 500, 500};

void Sound(u16 frq)
{
	u32 time;
	if(frq != 1000)
	{
		time = 500000/((u32)frq);
		PBeep = 1;
		delay_us(time);
		PBeep = 0;
		delay_us(time);
	}
	else
		delay_us(1000);
}

void Sound2(u16 time)
{
    PBeep = 1;
    delay_ms(time);
    PBeep = 0;
    delay_ms(time);
}
void play_successful(void)
{
    int id=0;
    for(id = 0 ;id < 12 ;id++)
    {
        Sound2(melody[id]);
    }
}
void play_failed(void)
{
    int id=0;
    for(id = 11 ;id >=0 ;id--)
    {
        Sound2(melody[id]);
    }
}

// ��7  1   2   3   4   5   6   7  ��1 ��2 ��3 ��4 ��5 ������
	uc16 tone[] = {247,262,294,330,349,392,440,294,523,587,659,698,784,1000};//��Ƶ���ݱ�
	//�쳾���
	u8 music_HongChenQingGe[]={5,5,6,8,7,6,5,6,13,13,//����
                5,5,6,8,7,6,5,3,13,13,
                2,2,3,5,3,5,6,3,2,1,
                6,6,5,6,5,3,6,5,13,13,

                5,5,6,8,7,6,5,6,13,13,
                5,5,6,8,7,6,5,3,13,13,
                2,2,3,5,3,5,6,3,2,1,
                6,6,5,6,5,3,6,1,	

                13,8,9,10,10,9,8,10,9,8,6,
                13,6,8,9,9,8,6,9,8,6,5,
                13,2,3,5,5,3,5,5,6,8,7,6,
                6,10,9,9,8,6,5,6,8};	
	u8 time_HongChenQingGe[] = {2,4,2,2,2,2,2,8,4, 4, //ʱ��
                2,4,2,2,2,2,2,8,4, 4, 
                2,4,2,4,2,2,4,2,2,8,
                2,4,2,2,2,2,2,8,4 ,4, 

                2,4,2,2,2,2,2,8,4, 4, 
                2,4,2,2,2,2,2,8,4, 4, 
                2,4,2,4,2,2,4,2,2,8,
                2,4,2,2,2,2,2,8,

                4, 2,2,2, 4, 2,2,2, 2,2,8,
                4, 2,2,2,4,2,2,2,2,2,8,
                4, 2,2,2,4,2,2,5,2,6,2,4,
                2,2 ,2,4,2,4,2,2,12};	
	
		//С����
		u8 music_XiaoYanZi[]={3,5,8,6,5,13,//����
	                3,5,6,8,5,13,
	                8,10,9,8,9,8,6,8,5,13,
					3,5,6,5,6,8,9,5,6,13,
					3,2,1,2,13,
					2,2,3,5,5,8,2,3,5,13};
		u8 time_XiaoYanZi[] ={2,2,2,2,6,4,//ʱ��  
				2,2,2,2,6,4,
                6,2,4,4,2,2,2,2,6,4,
				6,2,4,2,2,4,2,2,6,4,
				2,2,4,6,4,
				4,2,2,4,4,4,2,2,6,4};
		
		//С����
		u8 music_XiaoXingXing[] = {1, 1, 5, 5, 6, 6, 5, 4, 4, 3, 3, 2, 2, 1, 
                            5, 5, 4, 4, 3, 3, 2, 5, 5, 4, 4, 3, 3, 2, 
                            1, 1, 5, 5, 6, 6, 5, 4, 4, 3, 3, 2, 2, 1};
		u8 time_XiaoXingXing[] = {4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 7, 
                           4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 7, 
                           4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 7};
		
		//����ֻ�������
		u8 music_Mama[] = {1, 2, 3, 3, 4, 5, 5, 4, 3, 2, 1, 1, 
                   2, 3, 3, 2, 2, 3, 3, 4, 5, 5, 4, 3, 
                   2, 1, 1, 2, 2, 1, 2, 3, 3, 4, 5, 5, 
                   4, 3, 2, 1, 1, 2, 3, 2, 1};
		u8 time_Mama[] = {4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
                  4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
                  4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
                  4, 4, 4, 4, 4, 4, 4, 4, 4};		
		
		u8 music_short_1[] = {1, 2, 3, 4, 5};
		u8 time_short_1[] = {2, 3, 4, 5, 6};
		
		u8 music_short_2[] = {3, 4, 5, 4, 3};
		u8 time_short_2[] = {3, 2, 4, 3, 5};




		
void play_music(void)
{
	
	u32 yanshi;
	u16 i,e;
	yanshi = 10;
								
//	#define music  music_XiaoXingXing
//	#define time  time_XiaoXingXing

//	#define music  music_XiaoYanZi
//	#define time  time_XiaoYanZi	
	
		#define music  music_short_1
		#define time  time_short_1	
								
	for(i=0;i<sizeof(music)/sizeof(music[0]);i++)
		{
		for(e=0;e<((u16)time[i])*tone[music[i]]/yanshi;e++)
									{
			Sound((u32)tone[music[i]]);
		}	
	}
}





void Buzzer_On(void) 
{
    u32 time = 1000; // ���÷��������ʱ�䣨���룩
    u16 frq = 100; // ���÷�������Ƶ�ʣ����ȣ���������440HzΪ�����ӽ������е�A4��

    Sound(frq); // ����Sound�������÷�������ָ��Ƶ��������
    delay_ms(time); // ��ʱ����������ָ����ʱ��
}

void Buzzer_Off()
{
	 PBeep = 0;
}
