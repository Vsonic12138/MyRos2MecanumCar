/***********************************************************************
Copyright (c) 2022, www.guyuehome.com

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

? ? http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***********************************************************************/
#ifndef __PROTOCOL_H__
#define __PROTOCOL_H__

#include "headfile.h"

// ����ṹ��洢����
typedef struct 
{
    uint8_t header;           // ͷ����ʶ
    int16_t gyro_x;           // X����ٶ�
    int16_t gyro_y;           // Y����ٶ�
    int16_t gyro_z;           // Z����ٶ�
    int16_t roll;             // Roll�Ƕ�
    int16_t pitch;            // Pitch�Ƕ�
    int16_t yaw;              // Yaw�Ƕ�
    int16_t velocity_x;       // X���ٶ�
    int16_t velocity_y;       // Y���ٶ�
    int16_t velocity_z;       // Z���ٶ�
    int16_t distance_x;       // X��λ��
    int16_t distance_y;       // Y��λ��
    uint8_t checksum;         // У��λ
    uint8_t tail;             // β����ʶ
} SensorData;

extern SensorData data;

extern float forward_speed;  // ǰ���ٶ�
extern float backward_speed; // �����ٶ�
extern float left_speed;     // �����ٶ�
extern float right_speed;    // �����ٶ�
extern float turn_left_speed;// ��ת�ٶ�
extern float turn_right_speed;// ��ת�ٶ�



extern int speed_flag;
#define BuffLEN 25
extern uint8_t Data_Buffer[BuffLEN];

void Upper_Data_Receive(u8 JudgeReceiveBuffer[]);
void init_Flag_DataArray(void);
void Motion_Send_Data(void);
void Acc_Send_Data(void);
void Gyro_Send_Data(void);
void Angle_Send_Data(void);
void Sensor_Send_Data(void);
void Speed_Send_Data(void);
void Distance_Send_Data(void);

void ROS2_KeyBorad_Control_Task(void);
void Stm32_X3_Data_Pub(void);


#endif
