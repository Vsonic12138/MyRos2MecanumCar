#ifndef __KEY_H
#define __KEY_H	 
#include "headfile.h"
  	 

void MyDMA_Init(uint32_t AddrA, uint32_t AddrB, uint16_t Size);
void MyDMA_Transfer(void);

			    
#endif
