#ifndef _TIMER_H
#define _TIMER_H

/*ʱ����Ʊ�־λ*/
extern int count_10ms;
extern int count_20ms;
extern int count_40ms;
extern int count_100ms;
extern int count_200ms;
extern int count_500ms;


#include "headfile.h"

void TIM6_Timer_Init(u16 arr,u16 psc);
void TIM7_Timer_Init(u16 arr,u16 psc);



#endif

