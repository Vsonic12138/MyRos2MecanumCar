#ifndef __ADC_H
#define __ADC_H	
#include "headfile.h"

/*��ص�ѹ������*/
extern float Battery_voltage;

void Adc_Init(void);
float Get_adc(u8 ch);
float Get_adc_Average(u8 ch,u8 times);

void Get_Battery_Voltage(void);
 
#endif 
