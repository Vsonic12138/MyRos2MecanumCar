#ifndef __Car_Speed_H
#define __Car_Speed_H

#include "headfile.h"

#define ENCODER_ID_A  3
#define ENCODER_ID_B  2
#define ENCODER_ID_C  5
#define ENCODER_ID_D  4

// ����ǰ�����ٶ�
extern int leftFrontSpeedNow;
extern int rightFrontSpeedNow;
extern int leftBackSpeedNow;
extern int rightBackSpeedNow;

// ����ǰ������
extern double lFSpd_mm_s;
extern double rFSpd_mm_s;
extern double lBSpd_mm_s;
extern double rBSpd_mm_s;

//���㳵��ʵ���߹��ľ���
extern float Encoder_Sum_A;
extern float Encoder_Sum_B;
extern float Encoder_Sum_C;
extern float Encoder_Sum_D;
extern float Act_Distance_A;
extern float Act_Distance_B;
extern float Act_Distance_C;
extern float Act_Distance_D;
extern float Act_Distance;

void Get_Motor_Speed(int *leftFrontSpeed, int *rightFrontSpeed, int *leftBackSpeed, int *rightBackSpeed);
void Encoder_Update_Count(u8 Encoder_id);
int Encoder_Get_Count_Now(u8 Encoder_id);
void Distance_Calculation(void);

#endif

