#include "wifi.hpp"

//********************WIFI信息*******************//
const char* ssid = "pi";                                  //修改，你的路由器WIFI名字
const char* password = "123456789";                       //你的WIFI密码

//连接wifi
void setup_wifi() 
{
  delay(10);
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) 
  {
    delay(500);
    Serial.print("正在连接至wifi...");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
}