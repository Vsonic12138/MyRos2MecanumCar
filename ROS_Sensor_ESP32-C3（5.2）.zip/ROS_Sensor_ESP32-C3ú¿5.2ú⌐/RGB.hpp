#ifndef _RGB_H
#define _RGB_H

#include "Arduino.h"
#include <Adafruit_NeoPixel.h>    //RGB灯带控制函数


//RGB灯带颜色切换
void RGB_Brightness_Red();
void RGB_Brightness_Green();
void RGB_Brightness_Black();
void RGB_Brightness_Circulation();
void RGB_Breathing_Blue();
void RGB_Brightness_Circulation_Breathing();
void RGB_Brightness_Circulation_RandomColor();



#endif