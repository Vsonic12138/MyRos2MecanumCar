#include "Arduino.h"
#include "RGB.hpp"

//-----------------RGB灯带信息-----------------//
#define NUMPIXELS 60             // LED灯珠数量
#define RGB_PIN 1              // Arduino输出控制信号引脚
// define led according to pin diagram


/*---------------------------对象声明----------------------------*/
Adafruit_NeoPixel led(NUMPIXELS, RGB_PIN, NEO_GRB + NEO_KHZ800);


void RGB_Brightness_Red() 
{
  const long interval1 = 100;
  const int totalBlinks = 4;
  const int brightness = 50; // 设置亮度为100

  // 控制LED灯珠的状态
  for (int blinkCount = 0; blinkCount < totalBlinks; blinkCount++) {
    // 设置亮度
    led.setBrightness(brightness);

    // 闪烁状态
    for (int i = 0; i < NUMPIXELS; ++i) {
      led.setPixelColor(i, led.Color(255, 0, 0)); // 红色
    }
    led.show();
    delay(interval1);

    // 熄灭状态
    for (int i = 0; i < NUMPIXELS; ++i) {
      led.setPixelColor(i, led.Color(0, 0, 0)); // 关闭灯珠
    }
    led.show();
    delay(interval1);
  }

  // 设置亮度
  led.setBrightness(brightness);

  // 闪烁四次后，全部亮起并保持常亮状态
  for (int i = 0; i < NUMPIXELS; ++i) {
    led.setPixelColor(i, led.Color(255, 0, 0)); // 红色
  }
  led.show();
}


void RGB_Brightness_Green() 
{
  const long interval1 = 100;
  const int totalBlinks = 4;
  const int brightness = 50; // 设置亮度为100

  // 控制LED灯珠的状态
  for (int blinkCount = 0; blinkCount < totalBlinks; blinkCount++) {
    // 闪烁状态
    for (int i = 0; i < NUMPIXELS; ++i) {
      led.setPixelColor(i, led.Color(0, 255, 0)); // 绿色
    }
    led.show();
    delay(interval1);

    // 熄灭状态
    for (int i = 0; i < NUMPIXELS; ++i) {
      led.setPixelColor(i, led.Color(0, 0, 0)); // 关闭灯珠
    }
    led.show();
    delay(interval1);
  }

  // 设置亮度
  led.setBrightness(brightness);

  // 闪烁四次后，全部亮起并保持常亮状态
  for (int i = 0; i < NUMPIXELS; ++i) {
    led.setPixelColor(i, led.Color(0, 255, 0)); // 绿色
  }
  led.show();
}


void RGB_Brightness_Black() 
{
  unsigned long previousMillis4 = 0;  // 用于存储上一次改变LED状态的时间
  const long interval = 100;         // 每隔100毫秒改变一次LED状态
  // 获取当前时间
  unsigned long currentMillis4 = millis();

  // 控制LED灯珠的状态
  if (currentMillis4 - previousMillis4 >= interval) {
    previousMillis4 = currentMillis4; // 更新上一次改变LED状态的时间

    for (int i = 0; i < NUMPIXELS; ++i) { // 所有灯全部设为黑色
      led.setPixelColor(i, led.Color(0, 0, 0)); // 绿色
    }
    led.show();
  }
}


void RGB_Brightness_Circulation() 
{
  int currentPixel = 0;
  bool waterfallPerformed = false; // 标志位，记录是否已经执行过流水灯效果
  int brightness = 50; // 设置亮度为100

  if (!waterfallPerformed) { // 只执行一次流水灯效果
    // 进入无限循环，实现流水灯效果
    while (true) {
      // 设置亮度
      led.setBrightness(brightness);

      // 先将所有灯珠设置为关闭状态
      for (int i = 0; i < NUMPIXELS; ++i) {
        led.setPixelColor(i, led.Color(0, 0, 0)); // 关闭灯珠
      }

      // 点亮当前灯珠
      led.setPixelColor(currentPixel, led.Color(0, 255, 255)); // 设置为青色
      led.show();

      // 更新当前点亮的灯珠编号，并循环到0号灯珠
      currentPixel = (currentPixel + 1) % NUMPIXELS;

      // 添加适当的延迟，控制流水灯切换的速度
      delay(15); // 可以根据需要调整延迟时间

      if (currentPixel == 0) {
        // 流水灯效果执行完毕，将标志位设为true，并退出循环
        waterfallPerformed = true;
        break;
      }
    }
  }

  // 设置亮度
  led.setBrightness(brightness);

  // 流水灯效果执行完毕后，设置所有灯珠为白色（保持全部亮起）
  for (int i = 0; i < NUMPIXELS; ++i) {
    led.setPixelColor(i, led.Color(0, 255, 255)); // 设置为白色
  }
  led.show();
}



void RGB_Breathing_Blue() {
  const int maxBrightness = 60;  // 最大亮度值
  const int minBrightness = 0;    // 最小亮度值
  const int breathingSpeed = 5;  // 呼吸速度，可以根据需要调整

  for (int brightness = minBrightness; brightness <= maxBrightness; brightness++) {
    // 通过亮度值改变颜色的亮度，以实现呼吸灯效果
    for (int i = 0; i < NUMPIXELS; ++i) {
      led.setPixelColor(i, led.Color(0, 0, brightness)); // 淡蓝色
    }
    led.show();
    delay(breathingSpeed);
  }

  // 呼吸到最大亮度后，逐渐变暗
  for (int brightness = maxBrightness; brightness >= minBrightness; brightness--) {
    // 通过亮度值改变颜色的亮度，以实现呼吸灯效果
    for (int i = 0; i < NUMPIXELS; ++i) {
      led.setPixelColor(i, led.Color(0, 0, brightness)); // 淡蓝色
    }
    led.show();
    delay(breathingSpeed);
  }

  // 呼吸到最低亮度后，再次逐渐变亮
  for (int brightness = minBrightness; brightness <= maxBrightness; brightness++) {
    // 通过亮度值改变颜色的亮度，以实现呼吸灯效果
    for (int i = 0; i < NUMPIXELS; ++i) {
      led.setPixelColor(i, led.Color(0, 0, brightness)); // 淡蓝色
    }
    led.show();
    delay(breathingSpeed);
  }
}





void RGB_Brightness_Circulation_Breathing() 
{
  const int breathingSpeed = 5;    // 调整呼吸灯的速度，值越小速度越快
  static bool waterfallPerformed = false; // 标志位，记录是否已经执行过流水灯效果
  static int breathingCounter = 0;       // 记录呼吸灯效果执行次数

  if (!waterfallPerformed) { // 只执行一次流水灯效果
    int currentPixel = 0;
    // 进入无限循环，实现流水灯效果
    while (true) {
      // 先将所有灯珠设置为关闭状态
      for (int i = 0; i < NUMPIXELS; ++i) {
        led.setPixelColor(i, led.Color(0, 0, 0)); // 关闭灯珠
      }

      // 点亮当前灯珠
      led.setPixelColor(currentPixel, led.Color(0, 255, 255)); // 设置为青色
      led.show();

      // 更新当前点亮的灯珠编号，并循环到0号灯珠
      currentPixel = (currentPixel + 1) % NUMPIXELS;

      // 添加适当的延迟，控制流水灯切换的速度
      delay(15); // 可以根据需要调整延迟时间

      if (currentPixel == 0) {
        // 流水灯效果执行完毕，将标志位设为true，并退出循环
        waterfallPerformed = true;
        break;
      }
    }
  }

  // 流水灯效果结束后，亮起所有灯珠并执行呼吸灯效果
  if (waterfallPerformed) {
    const int maxBrightness = 30; // 最大亮度值
    const int minBrightness = 0;   // 最小亮度值

    while (true) { // 一直执行呼吸灯效果
      // 生成随机颜色
      int red = random(256);
      int green = random(256);
      int blue = random(256);

      for (int brightness = minBrightness; brightness <= maxBrightness; brightness++) {
        // 通过亮度值改变颜色的亮度，以实现呼吸灯效果
        for (int i = 0; i < NUMPIXELS; ++i) {
          led.setPixelColor(i, led.Color(red * brightness / maxBrightness, green * brightness / maxBrightness, blue * brightness / maxBrightness)); // 设置为随机颜色
        }
        led.show();
        delay(breathingSpeed);
      }

      for (int brightness = maxBrightness; brightness >= minBrightness; brightness--) {
        // 通过亮度值改变颜色的亮度，以实现呼吸灯效果
        for (int i = 0; i < NUMPIXELS; ++i) {
          led.setPixelColor(i, led.Color(red * brightness / maxBrightness, green * brightness / maxBrightness, blue * brightness / maxBrightness)); // 设置为随机颜色
        }
        led.show();
        delay(breathingSpeed);
      }
    }
  }
}




void RGB_Brightness_Circulation_RandomColor() 
{
  const int breathingSpeed = 5;    // 调整呼吸灯的速度，值越小速度越快
  static bool waterfallPerformed = false; // 标志位，记录是否已经执行过流水灯效果
  static bool breathingActive = false;    // 记录呼吸灯效果是否激活
  static int breathingCounter = 0;       // 记录呼吸灯效果执行次数
  static int colors[NUMPIXELS][3];       // 存储每个灯的颜色值

  if (!waterfallPerformed) { // 只执行一次流水灯效果
    int currentPixel = 0;
    // 进入无限循环，实现流水灯效果
    while (true) {
      // 先将所有灯珠设置为关闭状态
      for (int i = 0; i < NUMPIXELS; ++i) {
        led.setPixelColor(i, led.Color(0, 0, 0)); // 关闭灯珠
      }

      // 点亮当前灯珠
      led.setPixelColor(currentPixel, led.Color(0, 255, 255)); // 设置为青色
      led.show();

      // 更新当前点亮的灯珠编号，并循环到0号灯珠
      currentPixel = (currentPixel + 1) % NUMPIXELS;

      // 添加适当的延迟，控制流水灯切换的速度
      delay(15); // 可以根据需要调整延迟时间

      if (currentPixel == 0) {
        // 流水灯效果执行完毕，将标志位设为true，并退出循环
        waterfallPerformed = true;
        break;
      }
    }
  }

  // 流水灯效果结束后，亮起所有灯珠并执行呼吸灯效果
  if (waterfallPerformed && !breathingActive) {
    const int maxBrightness = 30; // 最大亮度值
    const int minBrightness = 0;   // 最小亮度值

    for (int i = 0; i < NUMPIXELS; ++i) {
      colors[i][0] = random(256); // 生成随机颜色
      colors[i][1] = random(256);
      colors[i][2] = random(256);
    }

    breathingActive = true;
  }

  if (breathingActive) {
    const int maxBrightness = 30; // 最大亮度值
    const int minBrightness = 0;   // 最小亮度值

    for (int breath = 0; breath < 2; breath++) { // 执行两次呼吸灯效果
      for (int brightness = minBrightness; brightness <= maxBrightness; brightness++) {
        // 通过亮度值改变颜色的亮度，以实现呼吸灯效果
        for (int i = 0; i < NUMPIXELS; ++i) {
          led.setPixelColor(i, led.Color(colors[i][0] * brightness / maxBrightness, colors[i][1] * brightness / maxBrightness, colors[i][2] * brightness / maxBrightness)); // 设置为随机颜色
        }
        led.show();
        delay(breathingSpeed);
      }

      for (int brightness = maxBrightness; brightness >= minBrightness; brightness--) {
        // 通过亮度值改变颜色的亮度，以实现呼吸灯效果
        for (int i = 0; i < NUMPIXELS; ++i) {
          led.setPixelColor(i, led.Color(colors[i][0] * brightness / maxBrightness, colors[i][1] * brightness / maxBrightness, colors[i][2] * brightness / maxBrightness)); // 设置为随机颜色
        }
        led.show();
        delay(breathingSpeed);
      }
    }

    // 标志呼吸灯效果已执行
    breathingCounter++;

    // 重置标志位，以便下一次函数调用重新执行效果
    if (breathingCounter >= 2) {
      waterfallPerformed = false;
      breathingActive = false;
      breathingCounter = 0;
    }
  }
}
