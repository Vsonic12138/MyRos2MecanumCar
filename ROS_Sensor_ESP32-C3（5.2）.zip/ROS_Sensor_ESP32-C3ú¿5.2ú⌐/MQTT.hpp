#ifndef _MQTT_H
#define _MQTT_H

#include "Arduino.h"
#include "PubSubClient.h"         //默认，加载MQTT库文件，库文件为PubSubClient by Nick
#include <SimpleDHT.h>            //dht11库文件,库文件为SimpleDHT by Winlin
#include "RGB.hpp"
#include "wifi.hpp"


//-----------------变量-----------------//
extern char msg1[50];                            //消息
#define pinDHT11   3            //DHT11传感器引脚 IO3
extern int Blueled;                    // define led according to pin diagram

extern WiFiClient espClient;
extern PubSubClient client;
extern SimpleDHT11 dht11;

void callback(char* topic, byte* payload, unsigned int length);
void reconnect(void);
void ESP32S3_Contorl_GPIO(String topic,String Cloud_Msg);
void Sensor_Read_And_Publish(void);
void turnOnLed(void);
void turnOffLed(void);
void extractBatteryVoltage(void);

#endif
