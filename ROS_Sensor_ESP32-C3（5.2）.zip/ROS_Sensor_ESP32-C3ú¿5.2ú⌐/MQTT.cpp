#include "MQTT.hpp"
/*
使用巴法云，连接较为简单
*/

//-----------------变量-----------------//
char msg1[50];                            //MQTT消息缓存区
int Blueled = 8;                          //板载小蓝灯，IO8
float Battery_voltage;
#define START_BYTE 0x55
#define END_BYTE 0xBB

//-----------------传感器信息主题-----------------//
//上发主题，添加/set可以避免发送者接收到信息
const char*  topic_Humidity = "Humidity/set";
const char*  topic_Tem = "Tem/set";
//接收主题
const char*  topic_Light = "Light";
const char*  topic_Battery = "Battery/set";

//********************云平台和WIFI信息*******************//
#define ID_MQTT  "fdbe476c609b472bb5ac71d0bc09e3ab"       //用户私钥，控制台获取


/*---------------------------对象声明----------------------------*/
WiFiClient espClient;
PubSubClient client(espClient);
SimpleDHT11 dht11(pinDHT11);


//回调函数
//ESP32接收到MQTT消息时，callback函数会被调用，并传递消息的相关信息：
//topic表示接收到消息的主题，payload是消息的有效负载（payload）的字节数组，length是有效负载的长度。
//在callback函数中，首先将接收到的主题和消息打印出来，方便调试和观察。
//然后，将字节数组的有效负载转换为字符串格式的msg，以便后续处理。
void callback(char* topic, byte* payload, unsigned int length) 
{
  //Serial.print("Topic:");
  //Serial.println(topic);
  String Cloud_Msg = "";  //Cloud_Msg定义为空，此处Cloud_Msg为局部变量
  //循环将收到的信息打印出来
  for (int i = 0; i < length; i++) 
  {
    Cloud_Msg += (char)payload[i];
  }
  Serial.print("Cloud_Msg:");
  Serial.println(Cloud_Msg);

  //进行判断，执行相应的操作
  ESP32S3_Contorl_GPIO(topic,Cloud_Msg);

  Cloud_Msg = ""; //清空msg
}


//重新连接函数
void reconnect() 
{
  // 不断循环直到连接到服务器
  while (!client.connected()) 
  {
    Serial.print("Attempting MQTT connection...");
    // Attempt to connect
    if (client.connect(ID_MQTT)) 
    {
      //println会多输出回车和换行，而print只会输出数据，不会额外加上回车和换行
      Serial.println("connected");
      
      //订阅主题
      client.subscribe(topic_Humidity);
      client.subscribe(topic_Tem);
      client.subscribe(topic_Light);
      client.subscribe(topic_Battery);

      Serial.println("subscribe OK:");

    } 
    else 
    {
      //如果没有订阅上，2s后重新执行订阅
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 2 seconds");
      //在重试连接前等待5s
      delay(2000);
    }
  }
}

//通过判断主题和消息来执行相应的程序
void ESP32S3_Contorl_GPIO(String topic,String Cloud_Msg)
{
  if (topic == "Light" && Cloud_Msg == "1") //如果接收字符on，亮灯
    {
      RGB_Brightness_Circulation();
      turnOnLed();  //开灯函数
    } 
  else if (topic == "Light" && Cloud_Msg == "2")  //如果接收字符off，灭灯
    {
      RGB_Brightness_Red();
    }
    else if (topic == "Light" && Cloud_Msg == "3")  //如果接收字符off，灭灯
    {
      RGB_Breathing_Blue();
    }
    else if (topic == "Light" && Cloud_Msg == "4")  //如果接收字符off，灭灯
    {
      RGB_Brightness_Green();
    }
      else if (topic == "Light" && Cloud_Msg == "5")  //如果接收字符off，灭灯
    {
      RGB_Brightness_Circulation_Breathing();
    }
      else if (topic == "Light" && Cloud_Msg == "6")  //如果接收字符off，灭灯
    {
      RGB_Brightness_Circulation_RandomColor();
    }

    
    else if (topic == "Light" && Cloud_Msg == "0")  //如果接收字符off，灭灯
    {
      RGB_Brightness_Black();
      turnOffLed(); //关灯函数
    }
  
    
}

//读取温湿度传感器并且上发
void Sensor_Read_And_Publish()
{
// read without samples.
    
    byte temperature = 0;
    byte humidity = 0;
    
    int err = SimpleDHTErrSuccess;
    if ((err = dht11.read(&temperature, &humidity, NULL)) != SimpleDHTErrSuccess) 
    {
      //Serial.print("Read DHT11 failed, err="); Serial.println(err); delay(1000);
      return;
    }

    String  msg_temperature = (String)temperature;
    String  msg_humidity = (String)humidity;
    String  msg_Battery = (String)Battery_voltage;

    //上发传感器数据
    client.publish(topic_Tem, msg_temperature.c_str());//数据上传
    client.publish(topic_Humidity, msg_humidity.c_str());//数据上传
    client.publish(topic_Battery, msg_Battery.c_str());//数据上传
   
}

// 接收并提取电池电量数据的函数
void extractBatteryVoltage() 
{
  static uint8_t receivedData[3]; // 包括起始字节、数据字节、结束字节
  static uint8_t dataIndex = 0;

  if (Serial.available() > 0) {
    uint8_t incomingByte = Serial.read();

    if (incomingByte == START_BYTE) {
      dataIndex = 0; // 重置数据索引
    }

    receivedData[dataIndex] = incomingByte;
    dataIndex++;

    if (dataIndex == 3) { // 当收到3个字节时，代表收到完整的数据帧
      if (receivedData[2] == END_BYTE) { // 检查结束字节
        // 提取电池电量值并返回
        Battery_voltage =  receivedData[1];
      }
    }
  }
  
  // 如果未收到完整的数据帧，则返回 0 表示数据未准备好
  //return 0;
}

//打开LED
void turnOnLed() 
{
  Serial.println("turn on light");
  //小蓝灯控制函数
  digitalWrite(Blueled, LOW);
  
}

//关闭LED
void turnOffLed() 
{
  Serial.println("turn off light");
  //小蓝灯控制函数
  digitalWrite(Blueled, HIGH);
}