import serial
import time
import pandas as pd
import os
from serial.tools import list_ports


def find_serial_ports():
    # 列出所有可用的串口
    ports = list(list_ports.comports())
    return [port.device for port in ports]

def select_serial_port(available_ports):
    print("可用串口:")
    for i, port in enumerate(available_ports):
        print(f"{i + 1}. {port}")

    while True:
        try:
            selection = int(input("请选择要使用的串口编号: "))
            if 1 <= selection <= len(available_ports):
                return available_ports[selection - 1]
            else:
                print("无效的选择，请重新输入.")
        except ValueError:
            print("请输入一个有效的数字.")


#加速度
def parse_STM32_Sensor_Data(data):
    Sensor_Data = {}
    print("传入的data:", ' '.join(format(byte, '02X') for byte in data))
    #角速度
    Sensor_Data['GyroX'] = (int.from_bytes(data[1:3], byteorder='little', signed=True))
    Sensor_Data['GyroY'] = (int.from_bytes(data[3:5], byteorder='little', signed=True))
    Sensor_Data['GyroZ'] = (int.from_bytes(data[5:7], byteorder='little', signed=True))
    #角度
    Sensor_Data['Roll'] = (int.from_bytes(data[7:9], byteorder='little', signed=True))
    Sensor_Data['Pitch'] = (int.from_bytes(data[9:11], byteorder='little', signed=True))
    Sensor_Data['Yaw'] = (int.from_bytes(data[11:13], byteorder='little', signed=True))
    #三轴实际速度，量纲为m/s
    Sensor_Data['Act_velocity_X'] = (int.from_bytes(data[13:15], byteorder='little', signed=True)) * 0.01
    Sensor_Data['Act_velocity_Y'] = (int.from_bytes(data[15:17], byteorder='little', signed=True)) * 0.01
    Sensor_Data['Act_velocity_Z'] = (int.from_bytes(data[17:19], byteorder='little', signed=True)) * 0.01
    #X、Y轴的实际位移距离，量纲为m
    Sensor_Data['Act_Distance_X'] = (int.from_bytes(data[19:21], byteorder='little', signed=True)) * 0.01
    Sensor_Data['Act_Distance_y'] = (int.from_bytes(data[21:23], byteorder='little', signed=True)) * 0.01
    #返回数据
    return Sensor_Data

def save_to_excel(data, filename):
    df = pd.DataFrame(data)
    df.to_excel(filename, index=False)
    print(f"数据已保存到 {filename}")

def init_excel_file(filename):
    df = pd.DataFrame(columns=['GyroX', 'GyroY', 'GyroZ', 'Roll', 'Pitch', 'Yaw', 'Act_velocity_X', 'Act_velocity_Y', 'Act_velocity_Z', 'Act_Distance_X', 'Act_Distance_Y'])
    df.to_excel(filename, index=False)
    print(f"Excel文件 {filename} 已创建")

def append_to_excel(data, filename):
    df = pd.read_excel(filename)
    df = pd.concat([df, pd.DataFrame([data])], ignore_index=True)
    df.to_excel(filename, index=False)
    print(f"数据已附加到 {filename}")

#用于计算校验位，获取全部的数据位，然后与上0XFF
def calculate_checksum(data):
    calcu_num = sum(data) & 0xFF
    print('校验结果如下：%#x' % calcu_num)
    return (calcu_num)

#用于判断帧头、帧尾、标志位和数据长度
def parse_serial_data(data):
    # 根据你的数据格式进行解析
    # 检查帧头和帧尾
    if data[0] != 0x55 or data[-1] != 0xBB:
        print("无效的数据帧")
        return None

    # 提取数据位
    data_payload = data[1:-2]
    #print("数据位是:")
    #print(data_payload)

    # 计算校验位
    received_checksum = data[-2]
    calculated_checksum = calculate_checksum(data_payload)

    # 验证校验位
    if calculated_checksum != received_checksum:
        print("校验失败")
        return None

    # 解析数据
    parsed_data = parse_STM32_Sensor_Data(data_payload)

    return parsed_data

def read_data_frame(ser):
    timeout = 1  # 设置超时时间为1秒
    start_time = time.time()

    frame_header_found = False  # 标志位，指示是否找到了帧头
    frame = b''  # 用于存储完整的数据帧

    # 读取数据帧
    while True:
        byte = ser.read(1)

        if byte == b'\x55' and not frame_header_found:  # 如果找到帧头
            frame_header_found = True
            frame = byte  # 存储帧头
        elif byte == b'\xBB' and frame_header_found:  # 如果找到帧尾
            frame += byte  # 存储帧尾
            break  # 结束读取
        elif not frame_header_found:  # 如果还没找到帧头
            continue
        else:  # 其他情况
            frame += byte  # 存储数据

        if time.time() - start_time > timeout:  # 超时
            return None

    print("完整数据帧:", ' '.join(format(byte, '02X') for byte in frame))
    return frame

def main():
    # 查找可用串口
    available_ports = find_serial_ports()

    if not available_ports:
        print("未找到可用串口")
        return

    # 手动选择串口
    selected_port = select_serial_port(available_ports)
    print(f"选择串口: {selected_port}")

    # 打开串口
    ser = serial.Serial(selected_port, baudrate=115200, timeout=1)

    # 初始化 Excel 文件
    excel_file = "sensor_data.xlsx"
    init_excel_file(excel_file)

    # 不断的读取串口数据，做解析并且输出
    try:
        while True:
            # 读取数据帧
            data = read_data_frame(ser)
            if not data:
                print("无法读取数据帧，可能是超时")
                continue

            # 解析数据
            parsed_data = parse_serial_data(data)
            if parsed_data:
                print("解析结果:", parsed_data)
                append_to_excel(parsed_data, excel_file)  # 将解析后的数据传递给 append_to_excel 函数

    except KeyboardInterrupt:
        print("程序已终止")

    finally:
        ser.close()

if __name__ == "__main__":
    main()

