#ifndef _wifi_H
#define _wifi_H

#include "Arduino.h"
#include <WiFi.h>                 //默认，加载WIFI头文件


void setup_wifi(void);



#endif
