#include "MQTT.hpp"

//-----------------变量-----------------//
char msg1[50];                            //消息
int Blueled = 8;                    // define led according to pin diagram

//-----------------传感器信息主题-----------------//
const char*  topic_Humidity = "Humidity/set";
const char*  topic_Tem = "Tem/set";
//灯 
const char*  topic_Light = "Light";

//********************云平台和WIFI信息*******************//
#define ID_MQTT  "fdbe476c609b472bb5ac71d0bc09e3ab"       //用户私钥，控制台获取


/*---------------------------对象声明----------------------------*/
WiFiClient espClient;
PubSubClient client(espClient);
SimpleDHT11 dht11(pinDHT11);


//回调函数
//ESP32接收到MQTT消息时，callback函数会被调用，并传递消息的相关信息：topic表示接收到消息的主题，payload是消息的有效负载（payload）的字节数组，length是有效负载的长度。
//在callback函数中，首先将接收到的主题和消息打印出来，方便调试和观察。
//然后，将字节数组的有效负载转换为字符串格式的msg，以便后续处理。
void callback(char* topic, byte* payload, unsigned int length) 
{
  //Serial.print("Topic:");
  //Serial.println(topic);
  String Cloud_Msg = "";  //Cloud_Msg定义为空，此处Cloud_Msg为局部变量
  for (int i = 0; i < length; i++) 
  {
    Cloud_Msg += (char)payload[i];
  }
  Serial.print("Cloud_Msg:");
  Serial.println(Cloud_Msg);

  ESP32S3_Contorl_GPIO(topic,Cloud_Msg);

  Cloud_Msg = ""; //清空msg
}


//重新连接函数
void reconnect() 
{
  // 不断循环直到连接到服务器
  while (!client.connected()) 
  {
    Serial.print("Attempting MQTT connection...");
    // Attempt to connect
    if (client.connect(ID_MQTT)) 
    {
      //println会多输出回车和换行，而print只会输出数据，不会额外加上回车和换行
      Serial.println("connected");
      
      client.subscribe(topic_Humidity);
      client.subscribe(topic_Tem);
      client.subscribe(topic_Light);

      Serial.println("subscribe OK:");

    } 
    else 
    {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      //在重试连接前等待5s
      delay(5000);
    }
  }
}

void ESP32S3_Contorl_GPIO(String topic,String Cloud_Msg)
{
  if (topic == "Light" && Cloud_Msg == "1") //如果接收字符on，亮灯
    {
      RGB_Brightness_Circulation();
      turnOnLed();  //开灯函数
    } 
  else if (topic == "Light" && Cloud_Msg == "2")  //如果接收字符off，灭灯
    {
      RGB_Brightness_Red();
      delay(500);
      RGB_Brightness_Black();
      delay(500);
      RGB_Brightness_Red();
      delay(500);
    }
    else if (topic == "Light" && Cloud_Msg == "3")  //如果接收字符off，灭灯
    {
      RGB_Breathing_Blue();
    }
    else if (topic == "Light" && Cloud_Msg == "4")  //如果接收字符off，灭灯
    {
      RGB_Brightness_Green();
    }
      else if (topic == "Light" && Cloud_Msg == "5")  //如果接收字符off，灭灯
    {
      RGB_Brightness_Circulation_Breathing();
    }
      else if (topic == "Light" && Cloud_Msg == "6")  //如果接收字符off，灭灯
    {
      RGB_Brightness_Circulation_RandomColor();
    }

    
    else if (topic == "Light" && Cloud_Msg == "0")  //如果接收字符off，灭灯
    {
      RGB_Brightness_Black();
      turnOffLed(); //关灯函数
    }
  

    
}

void Sensor_Read_And_Publish()
{
// read without samples.
    
    byte temperature = 0;
    byte humidity = 0;
    
    int err = SimpleDHTErrSuccess;
    if ((err = dht11.read(&temperature, &humidity, NULL)) != SimpleDHTErrSuccess) 
    {
      Serial.print("Read DHT11 failed, err="); Serial.println(err); delay(1000);
      return;
    }

    String  msg_temperature = (String)temperature;
    String  msg_humidity = (String)humidity;

    client.publish(topic_Tem, msg_temperature.c_str());//数据上传
    client.publish(topic_Humidity, msg_humidity.c_str());//数据上传
   
}

//打开灯泡
void turnOnLed() 
{
  Serial.println("turn on light");
  //小蓝灯控制函数
  digitalWrite(Blueled, LOW);
  
}

//关闭灯泡
void turnOffLed() 
{
  Serial.println("turn off light");
  //小蓝灯控制函数
  digitalWrite(Blueled, HIGH);
}